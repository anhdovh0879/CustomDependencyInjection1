package com.demo.framework.examples;

import com.demo.framework.annotations.CustomInject;

public class ControllerObject {
	private String ControllerName = "Default Controller Name";
	
	@CustomInject
	ServiceObject serviceObject;
	
	@CustomInject
	public ControllerObject(ServiceObject serviceObject)
	{
		this.serviceObject = serviceObject;
	}

	public ControllerObject() {
		// TODO Auto-generated constructor stub
	}

	public String getControllerName() {
		return ControllerName;
	}

	public void setControllerName(String controllerName) {
		ControllerName = controllerName;
	}

	public ServiceObject getServiceObject() {
		return serviceObject;
	}

	public void setServiceObject(ServiceObject serviceObject) {
		this.serviceObject = serviceObject;
	}
	
	
	
}
