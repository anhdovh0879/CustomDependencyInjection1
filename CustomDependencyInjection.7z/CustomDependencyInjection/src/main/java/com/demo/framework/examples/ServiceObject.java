package com.demo.framework.examples;

import com.demo.framework.annotations.CustomInject;

public class ServiceObject {
	private String ServiceName = "Default Service Name";
	
	@CustomInject
	BusinessObject businessObject;

	public String getServiceName() {
		return ServiceName;
	}

	public void setServiceName(String serviceName) {
		ServiceName = serviceName;
	}
	
	
}
