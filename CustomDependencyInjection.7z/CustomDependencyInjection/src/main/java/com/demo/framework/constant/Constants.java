package com.demo.framework.constant;

public class Constants {
	public static final String JAR_FILE_EXT = ".jar";
	public static final String JAVA_BINARY_EXTENSION = ".class";
}
