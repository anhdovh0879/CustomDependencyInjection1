package com.demo.framework.service;

import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import com.demo.framework.constant.Constants;

public class ClassLocator {
	public static Set<Class<?>> locateClassesByFile(File file) {
		Set<Class<?>> locatedClasses = new HashSet<Class<?>>();
		
		try {
			JarFile jarFile = new JarFile(file);
			Enumeration<JarEntry> entries = jarFile.entries();
			 while (entries.hasMoreElements()) {
				 JarEntry jarEntry = entries.nextElement();
				 if (!jarEntry.getName().endsWith(Constants.JAVA_BINARY_EXTENSION)) {
	                    continue;
	             }
				 
				 final String className = jarEntry.getName().replace(Constants.JAVA_BINARY_EXTENSION, "")
	                        .replaceAll("\\\\", ".")
	                        .replaceAll("/", ".");
				 locatedClasses.add(Class.forName(className));
			 }
		} catch (IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return locatedClasses;
	}
	
	public static Set<Class<?>> locateClassesByFolder(File directory) {
		Set<Class<?>> locatedClasses = new HashSet<Class<?>>();
		for (File file : directory.listFiles()) {
			locatingClasses(file,"",locatedClasses);
		}
		return locatedClasses;
	}
	
	private static void locatingClasses(File file, String pkgName, Set<Class<?>> locatedClasses){
		if(file.isDirectory()) {
			pkgName += file.getName()+".";
			for (File innerFile : file.listFiles()) {
				locatingClasses(innerFile, pkgName, locatedClasses);
			}
		}
		else {
			if(!file.getName().endsWith(Constants.JAVA_BINARY_EXTENSION)){
				return;
			}
			
			final String className = pkgName + file.getName().replace(Constants.JAVA_BINARY_EXTENSION, "")
																.replace("/", ".")
																.replace("\\\\", ".");
			try {
				locatedClasses.add(Class.forName(className));
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}
