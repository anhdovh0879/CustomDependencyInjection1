package com.demo.framework;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.demo.framework.annotations.CustomInject;

public class CustomDependencyInjector {
	
	public Object inject(Class<?> classToInject)
	{
		if(classToInject == null) {
			return null;
		}
		
		return injectFieldsIntoClass(classToInject);
	}

	private Object injectFieldsIntoClass(Class<?> classToInject) {
		// TODO Auto-generated method stub
		try {
			for (Constructor<?> constructor : classToInject.getConstructors()) {
				if(constructor.isAnnotationPresent(CustomInject.class)) {
					return injectFieldsViaConstructor(classToInject, constructor);
				}else {
					return injectFields(classToInject);
				}
			}
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return null;
		
	}

	private Object injectFields(Class<?> classToInject) {
		// TODO Auto-generated method stub
		try {
			Object o = classToInject.newInstance();
			for (Field field : classToInject.getDeclaredFields()) {
				if(field.isAnnotationPresent(CustomInject.class)) {
					field.setAccessible(true);
					field.set(o, field.getType().getConstructor().newInstance());
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	private Object injectFieldsViaConstructor(Class<?> classToInject, Constructor<?> constructor) {
		// TODO Auto-generated method stub
		try {
			Class<?>[] parameterTypes = constructor.getParameterTypes();
			Object[] objArr = new Object[parameterTypes.length];
			int i = 0;
			for (final Class<?> parameterType : parameterTypes) {
				objArr[i++] = parameterType.getConstructor().newInstance();
			}
			return classToInject.getConstructor(parameterTypes).newInstance(objArr);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
}
