package com.demo.framework.service;

import java.io.File;
import java.util.Set;

import com.demo.framework.constant.Constants;

public class ProjectScanner {
	public static Set<Class<?>> scanProject(String classPath) {
		Set<Class<?>> locatedClasses = null;
		File file = new File(classPath);
		if(!file.isDirectory() && classPath.endsWith(Constants.JAR_FILE_EXT))
		{
			System.out.println("File: "+ classPath);
			locatedClasses = ClassLocator.locateClassesByFile(file);
		}
		else
		{
			System.out.println("Folder: "+ classPath);
			locatedClasses = ClassLocator.locateClassesByFolder(file);
		}
		return locatedClasses;
	}
}
