package com.demo.framework.examples;

public class BusinessObject {
	private String BusinessName = "Default Business Name";

	public String getBusinessName() {
		return BusinessName;
	}

	public void setBusinessName(String businessName) {
		BusinessName = businessName;
	}
	
	
}
