package com.demo.framework;

import java.util.Set;

import com.demo.framework.examples.ControllerObject;
import com.demo.framework.service.ProjectScanner;

public class CustomInjector {
	
	public static void run(Class<?> runningClass)
	{
		//System.out.println(runningClass.getProtectionDomain().getCodeSource().getLocation().getFile());
		String classPath = runningClass.getProtectionDomain().getCodeSource().getLocation().getFile();
		Set<Class<?>> locatedClasses = ProjectScanner.scanProject(classPath);		
		CustomDependencyInjector customDependencyInjector= new CustomDependencyInjector();
		for (Class<?> locatedClass : locatedClasses) {
			customDependencyInjector.inject(locatedClass);
			/*
			ControllerObject controllerObject = (ControllerObject) customDependencyInjector.inject(locatedClass);
			if(controllerObject != null)
			{
				System.out.println("Debug: "+controllerObject.getServiceObject().getServiceName());
				
			}
			*/
			
		}
				
	}

}
